// Copyright 2015 Google Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

public class WellCompressed2 {
  public final static String DATA_001 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_002 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_003 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_004 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_005 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_006 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_007 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_008 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_009 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_010 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_011 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_012 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_013 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_014 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_015 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_016 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_017 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_018 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_019 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_020 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_021 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_022 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_023 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_024 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_025 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_026 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_027 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_028 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_029 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_030 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_031 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_032 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_033 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_034 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_035 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_036 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_037 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_038 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_039 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_040 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_041 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_042 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_043 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_044 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_045 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_046 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_047 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_048 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_049 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_050 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_051 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_052 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_053 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_054 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_055 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_056 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_057 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_058 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_059 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_060 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_061 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_062 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_063 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_064 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_065 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_066 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_067 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_068 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_069 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_070 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_071 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_072 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_073 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_074 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_075 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_076 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_077 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_078 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_079 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_080 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_081 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_082 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_083 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_084 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_085 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_086 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_087 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_088 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_089 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_090 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_091 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_092 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_093 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_094 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_095 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_096 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_097 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_098 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_099 = "                                    "
      + "                                                                    "
      + "                                                                    ";
  public final static String DATA_100 = "                                    "
      + "                                                                    "
      + "                                                                    ";
}

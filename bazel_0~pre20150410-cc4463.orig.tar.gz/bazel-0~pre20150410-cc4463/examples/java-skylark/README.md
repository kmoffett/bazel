Skylark Java Examples
=====================

Use the native Java rules (see the examples in _examples/java-native_) for
building Java, not these. These files are examples of how Skylark rules can be
used (see _tools/build_rules/java_rules_skylark.bzl_ for the rule definitions).
